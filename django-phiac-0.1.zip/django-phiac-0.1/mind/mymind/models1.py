from django.db import models
from django.urls import reverse

class Mindpower1(models.Model):
    given = models.CharField(max_length=100)
    since = models.CharField(max_length=100)
    therefore = models.CharField(max_length=100)
    is_there_another_way_to_do_this = models.TextField(max_length=2000)
    can_this_be_changed_to_bring_solution = models.TextField(max_length=2000)
    can_this_be_substituted_to_solve = models.TextField(max_length=2000)
    can_this_be_rearanged_differently = models.TextField(max_length=2000)
    can_the_opposite_be_done_for_a_solution = models.TextField(max_length=2000)
    share = models.CharField(max_length=100)
    comment = models.CharField(max_length=100)
    like = models.CharField(max_length=100)


    def __str__(self):
        return self.given
    def get_absolute_urls(self):
        return ('insight')

    def brain_image(request):
            if request.method == 'POST' and request.FILES['myfile']:
                myfile = request.FILES['myfile']
                fs = FileSystemStorage()
                filename = fs.save(myfile.name, myfile)
                uploaded_file_url = fs.url(filename)
                return render(request, 'two/complex_upload.html', {
                'uploaded_file_url': uploaded_file_url
            })
            return render(request, 'two/complex_upload.html')
