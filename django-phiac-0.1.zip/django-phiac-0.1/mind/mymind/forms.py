from django import forms
from .models import Mindpower

class Mymindpower(forms.ModelForm):

    class Meta:
        model = Mindpower
        fields = ['what_is_on_your_mind_you_want_say','reasoning','problem_or_issues_I_have_to_solve',
        'association_have_with_this_thought','collect_the_information_or_data_study_it',
        'given', 'since', 'therefore',
        'desirable_aspect_of_this_thought',
        'undesirable_aspect_of_this_thought',
        'evaluate_zero_to_ten_or_A_to_F','compare_advantages_and_disadvantages',
        'choose_one']
