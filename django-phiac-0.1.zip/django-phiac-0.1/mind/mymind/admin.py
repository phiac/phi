from django.contrib import admin
from .models import Mindpower, Mindpower4, Mindpower7, Mindpower8, Person, Person1, Person2, Mindpower6
from .models1 import Mindpower1
from .models2 import Mindpower2
from .models3 import Mindpower3, Photo
from .models5 import Mindpower5
# Register your models here.
admin.site.register(Mindpower)
admin.site.register(Person)
admin.site.register(Person1)
admin.site.register(Person2)
admin.site.register(Mindpower1)
admin.site.register(Mindpower2)
admin.site.register(Mindpower3)
admin.site.register(Mindpower4)
admin.site.register(Mindpower5)
admin.site.register(Photo)
admin.site.register(Mindpower6)
admin.site.register(Mindpower7)
admin.site.register(Mindpower8)
