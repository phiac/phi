from django import forms
from .models1 import Mindpower1

class Mymindpower1(forms.ModelForm):
    class Meta:
        model = Mindpower1
        fields = ['is_there_another_way_to_do_this',
        'can_this_be_changed_to_bring_solution','can_this_be_substituted_to_solve',
        'can_this_be_rearanged_differently','can_the_opposite_be_done_for_a_solution',
        'comment','share','like',
        'given', 'since', 'therefore'
        ]
