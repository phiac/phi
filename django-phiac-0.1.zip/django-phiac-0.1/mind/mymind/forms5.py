from django import forms
from .models5 import Mindpower5

class Mymindpower5(forms.ModelForm):
    class Meta:
        model = Mindpower5
        fields = [ 'message'
        ]
