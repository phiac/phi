from django.db import models
from django.utils.functional import cached_property


class Mindpower(models.Model):
    what_is_on_your_mind_you_want_say = models.CharField(max_length=200)
    reasoning = models.CharField(max_length=200)
    problem_or_issues_I_have_to_solve = models.TextField(max_length=1000)
    association_have_with_this_thought = models.TextField(max_length=1000)
    collect_the_information_or_data_study_it = models.TextField(max_length=5000)
    desirable_aspect_of_this_thought = models.TextField(max_length=1000)
    given = models.CharField(max_length=200)
    since = models.CharField(max_length=200)
    therefore = models.CharField(max_length=200)
    undesirable_aspect_of_this_thought = models.TextField(max_length=1000)
    evaluate_zero_to_ten_or_A_to_F = models.TextField(max_length=200)
    compare_advantages_and_disadvantages = models.TextField(max_length=1000)
    choose_one = models.CharField(max_length=100)
    #photo = models.ImageField()
    album_logo = models.FileField()


    def __str__(self):
        return self.reasoning

    def get_absolute_urls(self):
        return self.reasoning

#may need to separate these into separate models
class Person(models.Model):
    message = models.TextField(max_length=500)
    friends_photo = models.ImageField()


class HelpTextContactForm(models.Model):
     message = models.TextField(max_length=300)

class Person1(models.Model):
    message = models.TextField(max_length=500)
    friends_photo = models.ImageField()
    def get_absolute_url(self):
        return reverse('person1')
class Person2(models.Model):
    message = models.TextField(max_length=500)
    def __str__(self):
        return self.friend
    def get_absolute_url(self):
        return reverse('profile', kwargs={'pk':pk})
class Mindpower6(models.Model):
    name = models.CharField(max_length=100)
    album_logo = models.ImageField()
class Mindpower7(models.Model):
    name = models.CharField(max_length=100)
    album_logo = models.FileField()
class Mindpower4(models.Model):
    name = models.CharField(max_length=100)
    album_logo = models.FileField()
class Mindpower8(models.Model):
    name = models.CharField(max_length=200)
    album_logo = models.FileField()

    # @cached_property
    # def friends(self):
    #     # expensive computation
    #
    #     return friends
