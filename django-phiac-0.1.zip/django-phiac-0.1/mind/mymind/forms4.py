from django import forms
from .models import HelpTextContactForm

class TextContactForm(forms.ModelForm):
    message = forms.CharField()
    class Meta:
         model = HelpTextContactForm
         fields = ['message']
