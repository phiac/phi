
django-phiac/README.rst�

=====
phiac
=====

Phiac is an app to provide information about advance consciousness. 
Visitors can choose to try some of the methods to increase consciousness 
experience.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "phiac" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        
        'phiac',
    ]

2. Include the phiac URLconf in your project urls.py like this::

    path('phiac/', include('phiac.urls')),

3. Run `python manage.py migrate` if need to create the polls models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create experiences  (you'll need the Admin app enabled).

5. Visit http://phiac.com/ to participate in the process.

