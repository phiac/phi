from django.db import models
from django.urls import reverse

class Mindpower2(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    address = models.CharField(max_length=30)
    city = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    country = models.CharField(max_length=2000)
    zip = models.IntegerField()
    phone_number = models.IntegerField()
    education = models.CharField(max_length=100)
    bio = models.TextField(max_length=300)
    interests = models.CharField(max_length=100)
    e_mail = models.EmailField()
    website = models.CharField(max_length=100)
    photos = models.ImageField()

    def __str__(self):
        return self.first_name

    # def get_absolute_url(self):
    #     return reverse('profile')

    def get_queryset():
        return self.first_name


    def brain_image(request):
            if request.method == 'POST' and request.FILES['myfile']:
                myfile = request.FILES['myfile']
                fs = FileSystemStorage()
                filename = fs.save(myfile.name, myfile)
                uploaded_file_url = fs.url(filename)
                return render(request, 'two/complex_upload.html', {
                'uploaded_file_url': uploaded_file_url
            })
            return render(request, 'two/complex_upload.html')
