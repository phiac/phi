from django.shortcuts import render, redirect
from django.urls import reverse
from django.views.generic import View
from django.utils.translation import gettext
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.views.generic.edit import CreateView
from two.forms import DocumentForm
from two.models import Document
from . models import Mindpower, Person, Person1, HelpTextContactForm
from .models1 import Mindpower1
from .models2 import Mindpower2
from .models3 import Mindpower3, Photo
from .models5 import Mindpower5
from .models import Mindpower4, Mindpower8
from .models import Mindpower6
from django.template import RequestContext
from .models import Mindpower7
from . forms import Mymindpower
from . forms1 import Mymindpower1
from . forms2 import Mymindpower2
from . forms5 import Mymindpower5
from . forms3 import Person1ContactForm
from . forms4 import TextContactForm
from two.views import complex_upload
from mindqw.models import Album
from photvid.models import Movies
#from tropics.views import mymessage, HelpTextContactForm
from photvid.views import Phot, videos, PhotosCreate, Videos, MoviesCreate
from django.views.decorators.csrf import csrf_exempt, csrf_protect

# class IndexView(generic.ListView):
#     film = Films.objects.all()
#     # With class models context_object_name has to be present
#     # to enter the data into the template
#     context_object_name = 'film'
#     template_name = 'photvid/films.html'
#     def get_queryset(self):
#         return Films.objects.all()

def mind(request):
	ph = Phot.objects.all()
	vid = Videos.objects.all()
	photo = Photo.objects.all()
	all_contacts = HelpTextContactForm.objects.all
	# person1 = Person1.objects.all()
	mindpower6 = Mindpower6.objects.all()
	person = Person.objects.all()
	mindpower3 = Mindpower3.objects.all()

	args ={}
	args = (csrf_protect(request))
	mindpowers = Mindpower.objects.all()


	return render(request, 'mymind/mind.html', {'mindpowers':mindpowers, 'args':args,'mindpower3':mindpower3, 'photo':photo, 'person':person, 'all_contacts':all_contacts, 'mindpower6':mindpower6, 'ph':ph,'vid':vid })

def video(request, id):
	person = Person.objects.all()
	mindpower = Mindpower.objects.all()
	mindpower3 = Mindpower3.objects.all()
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# mindpowers3 = Mindpower3.objects.get(id=id)
	return render(request, 'mymind/ind.html', {'mindpower':mindpower,'mindpower3':mindpower3, 'person':person })

def ind(request):
	person = Person.objects.all()
	mindpower = Mindpower.objects.all()
	mindpower3 = Mindpower3.objects.all()
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# mindpowers3 = Mindpower3.objects.get(id=id)
	return render(request, 'mymind/ind.html', {'mindpower':mindpower,'mindpower3':mindpower3, 'person':person })
def ind1(request):
	person = Person.objects.all()
	mindpower = Mindpower.objects.all()
	all_albums = Album.objects.all()
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# mindpowers3 = Mindpower3.objects.get(id=id)
	return render(request, 'mymind/ind1.html', {'mindpower':mindpower,'all_albums':all_albums, 'person':person })
def ind2(request):
	person = Person.objects.all()
	mindpower7 = Mindpower7.objects.all()
	return render(request, 'mymind/ind2.html', {'mindpower7':mindpower7, 'person':person })
def ind3(request):
	person = Person.objects.all()
	mindpower = Mindpower.objects.all()
	mindpower4 = Mindpower4.objects.all()
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# mindpowers3 = Mindpower3.objects.get(id=id)
	return render(request, 'mymind/ind3.html', {'mindpower4':mindpower4,'mindpower':mindpower, 'person':person })
def ind4(request):
	movie = Movies.objects.all()
	person = Person.objects.all()
	mindpower = Mindpower.objects.all()
	mindpower8 = Mindpower8.objects.all()
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# mindpowers3 = Mindpower3.objects.get(id=id)
	return render(request, 'mymind/ind4.html', {'mindpower8':mindpower8,'mindpower':mindpower, 'person':person, 'movie':movie })
def ind5(request):
	person = Person.objects.all()
	movies = Movies.objects.all()
	return render(request, 'mymind/ind5.html', {'movies':movies,'person':person})

def getTwitter(request):
	tweet = []
	try:
		import twitter
		api = twitter.Api()
		latest = api.GetUserTimeline('jdarosa22')
		for tweet in latest:
			status = tweet.text
			tweet_date = tweet.relative_created_at
			tweets.append = ({'status':status, 'tweet_date':tweet_date})

	except:
		tweets.append({'status': 'Follow us @jadarosa22', 'date': 'about 10 minutes ago'})
	return {'tweets':tweets}
def photos(request):
	person = Person.objects.all()
	mindpower = Mindpower.objects.all()
	mindpower3 = Mindpower3.objects.all()
	return render(request, 'mymind/photos.html', {'mindpower':mindpower,'mindpower3':mindpower3, 'person':person})
class Message(CreateView):
	photo = Photo.objects.all()
	all_contacts = HelpTextContactForm.objects.all()
	template_name = 'mymind/helptextcontactform_form.html'
	model = TextContactForm
	fields = ['message']

def twitter(request):
	return render(request, 'bootstrap/twitter.html')

def indy(request):
	photo = Photo.objects.all()
	mindpower3 = Mindpower3.objects.all()
	return render(request, 'mymind/indy.html', {'mindpower3':mindpower3,'photo':photo})

def profile_form(request):
	forms2 = Mymindpower2(request.POST or None)
	if forms2.is_valid():
		forms2.save()
		return redirect('profile')
	return render(request, 'mymind/profile_form.html', {'forms2':forms2})

class Myprofile(CreateView):
    mindpowers2 = Mindpower2.objects.all()
    model = Mindpower2
    fields = ['first_name','last_name','address','city','state','country','zip','phone_number', 'bio','e_mail','website','education','interests']

def get_queryset(self, request):
	forms2 = self.form_class(None)
	return redirect('mind')
def myprofile(request):
	mindpowers2 = Mindpower2.objects.all()
	forms2 = Mymindpower2(request.POST or None)
	if forms2.is_valid():
		forms2.save()
		return redirect('mind')
		return render(request, 'mymind/profile_form.html', {'mindpowers2':mindpowers2})

def twitter1(request):
	return render(request, 'bootstrap/twitter1.html')

def profile(request, id):
	person = Person.objects.all()
	mindpower2 = Mindpower2.objects.all()
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# mindpowers3 = Mindpower3.objects.get(id=id)
	return render(request, 'mymind/profile.html', {'mindpower2':mindpower2, 'person':person})

def search(request):
	if search.method=="POST":
		search_text = request.POST['search_text']
	else:
		search_text=''
	mindpower = Mindpower.objects.filter(reasoning__contains=search_text)
	return render_to_response('ajax_search.html', {'mindpower':mindpower})

def create_mind(request):
	form = Mymindpower(request.POST or None)
	if form.is_valid():
		form.save()
		return redirect('index')
	return render(request, 'mymind/mind-form.html', {'form':form})

def com(request):
	mindpower3 = Mindpower3.objects.all()
	person = Person.objects.all()
	photo = Photo.objects.all()
	mindpower3 = Mindpower3.objects.all()
	# No meta is when the variable mindpower or mindpowers is not correct
	form5 = Mymindpower5(request.POST or None)
	if form5.is_valid():
		form5.save()
		return redirect('mind')
	return render(request, 'mymind/com.html', {'form5':form5,'person':person, 'mindpower3':mindpower3, 'photo':photo})

def update_mind(request, id):
	mindpowers = Mindpower.objects.all()
	mindpower = Mindpower.objects.get(id=id)
	form = Mymindpower(request.POST or None, instance=mindpower)
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# mindpowers3 = Mindpower3.objects.get(id=id)
	if form.is_valid():
		form.save()
		return redirect('mind')
	return render(request, 'mymind/mind-form.html', {'form':form, 'mindpower':mindpower, 'mindpowers':mindpowers})

def update_mind1(request, id):
	photo = Photo.objects.all()
	mindpower = Mindpower.objects.all()
	mindpowers = Mindpower1.objects.all()
	mindpower1 = Mindpower1.objects.get(id=id)
	forms1 = Mymindpower1(request.POST or None, instance=mindpower1)
	if forms1.is_valid():
		forms1.save()
		return redirect('mind')
	return render(request, 'mymind/mind-form1.html', {'forms1':forms1, 'mindpower':mindpower,'mindpowers':mindpowers,'mindpower1':mindpower1,'	photo':photo})

def delete_mind(request, id):
    mindpower = Mindpower.objects.get(id=id)
    if request.method == 'POST':
        mindpower.delete()
        return redirect('mind')
    return render(request, 'mymind/delete-mind.html', {'mindpower':mindpower})

def delete_mind1(request, id):
    mindpower1 = Mindpower1.objects.get(id=id)
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# mindpowers3 = Mindpower3.objects.get(id=id)
    if request.method == 'POST':
        mindpower1.delete()
        return redirect('mind')
    return render(request, 'mymind/delete-mind1.html', {'mindpower1':mindpower1})

def complex_uploaded(request):

		if request.method == 'POST' and request.FILES['myfile']:
			myfile = request.FILES['myfile']
			fs = FileSystemStorage()
			filename = fs.save(myfile.name, myfile)
			uploaded_file_url = fs.url(filename)
			return render(request, 'two/model_form_upload.html', {
			'uploaded_file_url': uploaded_file_url
			})
			filename = fs.save(myfile.name, myfile)
		return render(request, 'two/model_form_upload.html')
		mindpowers = Mindpower.objects.all()
		return render(request, 'mymind/mind.html', {'mindpowers':mindpowers})

from django.utils import feedgenerator
feed = feedgenerator.Rss201rev2Feed(
     title="Poynter E-Media Tidbits",
     link="http://www.poynter.org/column.asp?id=31",
     description="A group Weblog by the sharpest minds in online media/journalism/p;sublishing.",language="en",)
feed.add_item(
     title="Hello",
     link="http://www.holovaty.com/test/",
     description="Testing.",
 )
with open('test.rss', 'w') as fp:
	feed.write(fp, 'utf-8')

def friends(request):
	person = Person.objects.all()
	mindpower3 = Mindpower3.objects.all()
	return render(request, 'mymind/mind.html', {'person':person, 'mindpower3':mindpower3})

def detailfrnd(request, id):
	photo = Photo.objects.all()
	mindpower3 = Mindpower3.objects.all()
	mindpowers = Mindpower.objects.all()
	person = Person.objects.all()
	# The class lable is not given an a get id because it is not put into a form
	# Only form get the objects id with a get id in the body
	# person = Person.objects.get(id=id)
	return render(request, 'mymind/mind.html', {'person':person,'mindpowers':mindpowers, 'mindpower3':mindpower3, 'photo':photo})

def detailfrnd1(request, id):
	#Notice that the id and get is not in the body
	photo = Photo.objects.all()
	mindpowers = Mindpower.objects.all()
	person = Person.objects.all()
	return render(request, 'mymind/video.html', {'person':person,'mindpowers':mindpowers, 'photo':photo})

class Person1(CreateView):
	person1 = Person1.objects.all()
	def get_queryset(self, request):
		fields = ['message','friends_photo']

		template_name = 'mymind/person1_form.html'
		model = Person1ContactForm
		fields = ['message','friends_photo']
