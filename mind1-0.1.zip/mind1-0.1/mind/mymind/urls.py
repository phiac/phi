from django.conf.urls.static import static
from django.conf.urls import url
from django.views.generic import DetailView, CreateView
from django.conf import settings
from django.urls import path
from .models import Mindpower
from .models1 import Mindpower1
from .models5 import Mindpower5
from . import views
from photvid.views import videos, Phot, PhotosCreate
from .views import (ind, ind1, ind2, ind3, ind4, ind5, mind, video, photos, detailfrnd1, Message, create_mind, complex_uploaded,  detailfrnd, friends, update_mind,
update_mind1, delete_mind, delete_mind1, indy, Myprofile, myprofile, Person1, com, profile, profile_form, twitter, twitter1)
from django.views.generic import TemplateView

urlpatterns = [
    path('', mind, name='mind'),
    path('video/<int:id>/', video, name='video'),
    path('ind/', ind, name='ind'),
    path('ind1/', ind1, name='ind1'),
    path('ind2/', ind2, name='ind2'),
    path('ind3/', ind3, name='ind3'),
    path('ind4/', ind4, name='ind4'),
    path('ind5/', ind5, name='ind5'),
    # path('photos/', Photos, name='photos'),
    path('videos', videos, name='videos'),
    path('photos/add/', PhotosCreate, name='photos-add'),
    # path('mymessage/', mymessage, name='mymessage'),
    path('message/', Message.as_view(), name='helptextcontactform_form'),
    path('mind/', friends, name='mind'),
    path('person/', Person1.as_view(), name='person'),
    path('detailfrnd/<int:id>/', detailfrnd, name='detailfrnd'),
    path('detailfrnd1/<int:id>/', detailfrnd1, name='detailfrnd1'),
    path('start/', create_mind, name='create_mind'),
    path('indy/', indy, name='indy'),
    path('photos/', photos, name='photos'),
    path('m/', com, name='com'),
    path('profile/<int:id>/', profile, name='profile'),
    path('myprofile/', myprofile, name='profile_form'),
    path('pro/', Myprofile.as_view(), name='profile_form'),
    path('profile_form/', profile_form, name='profile_form'),
    path('twitter/', TemplateView.as_view(template_name='bootstrap/twitter.html')),
    path('twitter1/', TemplateView.as_view(template_name='bootstrap/twitter1.html')),
    path('update/<int:id>/', update_mind, name='update_mind'),
    path('update_mind1/<int:id>/', update_mind1, name='mind-form1'),
    path('index-b/', TemplateView.as_view(template_name='bootstrap/example.html')),
    path('delete/<int:id>/', delete_mind, name='delete_mind'),
    path('delete1/<int:id>/', delete_mind1, name='delete_mind1'),
    path('complex_uploaded/', complex_uploaded, name='complex_uploaded'),

]
