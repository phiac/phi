from django.db import models


class Mindpower5(models.Model):
    message = models.TextField(max_length=300)

    def __str__(self):
        return self.message

    def get_absolute_urls(self):
        return ('com')
