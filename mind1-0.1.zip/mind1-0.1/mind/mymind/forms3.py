from django import forms
from .models import Person1

class Person1ContactForm(forms.Form):
    message = forms.Textarea()
    friends_photo = forms.ImageField()
