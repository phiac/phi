from django import forms
from .models2 import Mindpower2

class Mymindpower2(forms.ModelForm):
    class Meta:
        model = Mindpower2
        fields = ['first_name',
        'last_name','address',
        'city','state',
        'country','zip',
        'phone_number', 'bio',
        'e_mail','website',
        'education','interests'
        ]
