from django.db import models
# from django.utils.functional import cached_property


class Mindpower3(models.Model):
    name = models.CharField(max_length=100)
    album_logo = models.FileField()

    def __str__(self):
        return self.name

    def get_absolute_urls(self):
        return ('video')

class Photo(models.Model):
    Messages = models.CharField(max_length=100)
    friends_photo = models.ImageField()


    # def __str__(self):
    #     return self.messages

    def get_absolute_url(self):
        return reverse('index')

    # @cached_property
    # def friends(self):
    #     # expensive computation
    #
    #     return friends
