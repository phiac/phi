from django.apps import AppConfig


class MymindConfig(AppConfig):
    name = 'mymind'
